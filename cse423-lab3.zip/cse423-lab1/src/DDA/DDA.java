package DDA;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;

import javax.swing.*;

class ThirdGLEventListener implements GLEventListener {
    /**
     * Interface to the GLU library.
     */
    private GLU glu;

    /**
     * Take care of initialization here.
     */
    public void init(GLAutoDrawable gld) {
        GL2 gl = gld.getGL().getGL2();
        glu = new GLU();

        gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        gl.glViewport(-250, -150, 250, 150);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluOrtho2D(-250.0, 250.0, -150.0, 150.0);
    }

    /**
     * Take care of drawing here.
     */
    public void display(GLAutoDrawable drawable) {
        GL2 gl = drawable.getGL().getGL2();

        gl.glClear(GL2.GL_COLOR_BUFFER_BIT);
        /*
         * put your code here
         */
        drawLine(gl, 5, 20, 10, 25);
        drawLine(gl, 10, 25, 15, 20);
        drawLine(gl, 15, 30, 20, 25);
        drawLine(gl, 20, 25, 10, 15);
        drawLine(gl, 15, 20, 20, 15);
        drawLine(gl, 20, 15, 25, 20);
        drawLine(gl, 10, 15, 15, 10);



    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width,
                        int height) {
    }

    public void displayChanged(GLAutoDrawable drawable,
                               boolean modeChanged, boolean deviceChanged) {
    }

    private void drawLine(GL2 gl, int x1, int y1, int x2, int y2) {

        int x= x1, y=y1;
        int dx = x2-x1;
        int dy = y2-y1;
        int lastStep;
        float xInc, yInc;
        gl.glPointSize(1f);

        if (Math.abs(dx) > Math.abs(dy)){
            lastStep = Math.abs(dx);
        }
        else{
            lastStep = Math.abs(dy);
        }

        xInc = dx / (float) lastStep;
        yInc = dy / (float) lastStep;

        gl.glBegin(GL2.GL_POINTS);
        for (int i=0; i <lastStep; i++){
            gl.glVertex2i(x, y);
                    x += (int) xInc;
            y += (int) yInc;
        }

        gl.glEnd();

    }

    public void dispose(GLAutoDrawable arg0) {

    }
}

public class DDA {
    public static void main(String args[]) {
        //getting the capabilities object of GL2 profile
        final GLProfile profile = GLProfile.get(GLProfile.GL2);
        GLCapabilities capabilities = new GLCapabilities(profile);
        // The canvas
        final GLCanvas glcanvas = new GLCanvas(capabilities);
        ThirdGLEventListener b = new ThirdGLEventListener();
        glcanvas.addGLEventListener(b);
        glcanvas.setSize(400, 400);
        //creating frame
        final JFrame frame = new JFrame("Basic frame");
        //adding canvas to frame
        frame.add(glcanvas);
        frame.setSize(640, 480);
        frame.setVisible(true);
    }
}